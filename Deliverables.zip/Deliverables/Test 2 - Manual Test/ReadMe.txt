1) Go through "TestData-Setup.docx", to configure Multi Value Custom Data in the system.
2) Open "Test Plan_Scenarios_TestCases.xlsx" and execute respective testcase using the test data available in TestData Folder for the Contact Type
3) Go through "TestExecution_Bugs.docx" for detailed obeservations.

